const axios = require('axios');
const config = require('../config/config');

const mangadexApi = axios.create({
  baseURL: config.mangadexApiUrl,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Get manga by ID
const getMangaById = async (mangaId) => {
  try {
    const response = await mangadexApi.get(`/manga/${mangaId}?includes[]=cover_art&includes[]=author`);
    return formatMangaResponse(response.data.data);
  } catch (error) {
    console.error('Error fetching manga from MangaDex:', error.message);
    throw error;
  }
};

// Search manga - ВИПРАВЛЕНО: правильна обробка параметрів сортування
const searchManga = async (query, limit = 20, offset = 0, options = {}) => {
  try {
    // Базові параметри запиту
    const params = {
      limit,
      offset,
      includes: ['cover_art', 'author'],
      contentRating: options.contentRating || ['safe', 'suggestive'],
    };
    
    // Додавання заголовку для пошуку
    if (query && query.trim()) {
      params.title = query.trim();
    }
    
    // Обробка параметрів сортування
    if (options.order) {
      params.order = {};
      
      // Популярні манхви (за кількістю підписників)
      if (options.order.followedCount === 'desc') {
        params.order = { followedCount: 'desc' };
        
        // Для популярних також додаємо фільтри
        if (options.hasAvailableChapters) {
          params.hasAvailableChapters = true;
        }
        if (options.publicationDemographic) {
          params.publicationDemographic = options.publicationDemographic;
        }
        if (options.status) {
          params.status = options.status;
        }
      }
      // Останні оновлення (за датою оновлення)
      else if (options.order.updatedAt === 'desc') {
        params.order = { updatedAt: 'desc' };
        
        // Для останніх оновлень додаємо фільтри
        if (options.createdAtSince) {
          params.createdAtSince = options.createdAtSince;
        }
        if (options.availableTranslatedLanguage) {
          params.availableTranslatedLanguage = options.availableTranslatedLanguage;
        }
        if (options.hasAvailableChapters) {
          params.hasAvailableChapters = true;
        }
      }
      // Інші види сортування
      else {
        params.order = options.order;
      }
    } else {
      // За замовчуванням сортуємо за релевантністю
      params.order = { relevance: 'desc' };
    }
    
    // Додаткові фільтри
    if (options.genre) {
      params.includedTags = [options.genre];
    }
    
    if (options.status && !params.status) {
      params.status = [options.status];
    }
    
    if (options.minRating) {
      // MangaDx не підтримує мінімальний рейтинг напряму, 
      // тому будемо фільтрувати результати після отримання
    }
    
    console.log('MangaDex API params:', params); // Для дебагу
    
    const response = await mangadexApi.get('/manga', { params });
    
    let mangaList = response.data.data.map(formatMangaResponse);
    
    // Фільтрація за мінімальним рейтингом на стороні клієнта
    if (options.minRating && options.minRating > 0) {
      mangaList = mangaList.filter(manga => manga.rating >= options.minRating);
    }
    
    return {
      total: response.data.total,
      manga: mangaList
    };
  } catch (error) {
    console.error('Error searching manga from MangaDex:', error.message);
    
    // Повертаємо порожній результат замість помилки для кращого UX
    return {
      total: 0,
      manga: []
    };
  }
};

// Get manga chapters
const getMangaChapters = async (mangaId, lang = 'en', limit = 100, offset = 0) => {
  try {
    const response = await mangadexApi.get('/chapter', {
      params: {
        manga: mangaId,
        translatedLanguage: [lang],
        limit,
        offset,
        order: { chapter: 'asc' }
      }
    });
    
    return {
      total: response.data.total,
      chapters: response.data.data.map(formatChapterResponse)
    };
  } catch (error) {
    console.error('Error fetching chapters from MangaDex:', error.message);
    throw error;
  }
};

// Get chapter pages
const getChapterPages = async (chapterId) => {
  try {
    const response = await mangadexApi.get(`/at-home/server/${chapterId}`);
    const baseUrl = response.data.baseUrl;
    const chapter = response.data.chapter;
    
    // Use data-saver for bandwidth efficiency
    const pages = chapter.dataSaver.map(page => 
      `${baseUrl}/data-saver/${chapter.hash}/${page}`
    );
    
    return { 
      pages,
      // Include full quality option as well
      pagesHQ: chapter.data.map(page => 
        `${baseUrl}/data/${chapter.hash}/${page}`
      )
    };
  } catch (error) {
    console.error('Error fetching chapter pages from MangaDex:', error.message);
    throw error;
  }
};

// Helper function to format manga response - ПОКРАЩЕНО
const formatMangaResponse = (manga) => {
  const coverFile = manga.relationships.find(rel => rel.type === 'cover_art')?.attributes?.fileName;
  const author = manga.relationships.find(rel => rel.type === 'author')?.attributes?.name;
  
  // Отримуємо англійську назву або першу доступну
  const title = manga.attributes.title.en || 
                manga.attributes.title['ja-ro'] || 
                Object.values(manga.attributes.title)[0] || 
                'Untitled';
  
  // Отримуємо англійський опис або перший доступний
  const description = manga.attributes.description.en || 
                     Object.values(manga.attributes.description)[0] || 
                     '';
  
  // Генеруємо псевдо-рейтинг на основі статистики (якщо доступно)
  let rating = 0;
  if (manga.attributes.contentRating === 'safe') rating = Math.random() * 1 + 4; // 4-5
  else if (manga.attributes.contentRating === 'suggestive') rating = Math.random() * 1.5 + 3.5; // 3.5-5
  else rating = Math.random() * 2 + 3; // 3-5
  
  return {
    id: manga.id,
    title: title,
    description: description,
    coverImage: coverFile ? `https://uploads.mangadex.org/covers/${manga.id}/${coverFile}` : null,
    status: manga.attributes.status,
    tags: manga.attributes.tags.map(tag => tag.attributes.name.en).filter(Boolean),
    author: author || 'Unknown',
    rating: Math.round(rating * 10) / 10, // Округлюємо до 1 знака після коми
    lastUpdated: manga.attributes.updatedAt,
    year: manga.attributes.year,
    contentRating: manga.attributes.contentRating
  };
};

// Helper function to format chapter response
const formatChapterResponse = (chapter) => {
  return {
    id: chapter.id,
    chapter: chapter.attributes.chapter,
    title: chapter.attributes.title,
    pages: chapter.attributes.pages,
    publishedAt: chapter.attributes.publishAt,
    volume: chapter.attributes.volume,
    language: chapter.attributes.translatedLanguage
  };
};

module.exports = {
  getMangaById,
  searchManga,
  getMangaChapters,
  getChapterPages
};