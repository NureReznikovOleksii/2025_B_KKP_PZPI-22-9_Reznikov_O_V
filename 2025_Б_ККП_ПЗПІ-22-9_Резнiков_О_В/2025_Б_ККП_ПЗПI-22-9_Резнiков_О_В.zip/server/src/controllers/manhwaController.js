const { validationResult } = require('express-validator');
const ManhwaProgress = require('../models/ManhwaProgress');
const User = require('../models/User');
const { 
  getMangaById, 
  searchManga, 
  getMangaChapters, 
  getChapterPages 
} = require('../utils/mangadexUtils');
const { EXP_REWARDS } = require('../utils/experienceUtils');

// Search manhwas
const searchManhwas = async (req, res, next) => {
  try {
    const { query, limit = 20, offset = 0 } = req.query;
    
    if (!query) {
      return res.status(400).json({ message: 'Search query is required' });
    }
    
    const results = await searchManga(query, parseInt(limit), parseInt(offset));
    res.json(results);
  } catch (error) {
    next(error);
  }
};

// Get manhwa details
const getManhwaDetails = async (req, res, next) => {
  try {
    const { manhwaId } = req.params;
    
    // Get manga details from MangaDx
    const manga = await getMangaById(manhwaId);
    
    // If authenticated, get user progress
    let userProgress = null;
    if (req.user) {
      userProgress = await ManhwaProgress.findOne({
        user: req.user.id,
        manhwaId
      });
    }
    
    res.json({
      manga,
      userProgress
    });
  } catch (error) {
    next(error);
  }
};

// Get manhwa chapters
const getManhwaChapters = async (req, res, next) => {
  try {
    const { manhwaId } = req.params;
    const { lang = 'en', limit = 100, offset = 0 } = req.query;
    
    const chapters = await getMangaChapters(
      manhwaId, 
      lang, 
      parseInt(limit), 
      parseInt(offset)
    );
    
    res.json(chapters);
  } catch (error) {
    next(error);
  }
};

// Get chapter pages
const getChapterContent = async (req, res, next) => {
  try {
    const { chapterId } = req.params;
    
    const pages = await getChapterPages(chapterId);
    res.json(pages);
  } catch (error) {
    next(error);
  }
};

// Update reading progress - ВИПРАВЛЕНО: додана перевірка на дублікати запитів
const updateReadingProgress = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    const { manhwaId } = req.params;
    const { 
      lastChapterRead, 
      isCompleted, 
      rating,
      review,
      status,
      isLiked
    } = req.body;
    
    // Додана перевірка на валідність manhwaId
    if (!manhwaId || manhwaId.length < 10) {
      return res.status(400).json({ message: 'Invalid manhwa ID' });
    }
    
    // ВАЖЛИВО: Перевірка на дублікати запитів протягом короткого часу
    const cacheKey = `progress_update_${req.user.id}_${manhwaId}`;
    if (req.app.locals.progressCache && req.app.locals.progressCache[cacheKey]) {
      const lastUpdate = req.app.locals.progressCache[cacheKey];
      if (Date.now() - lastUpdate < 2000) { // 2 секунди
        return res.json({ message: 'Progress update ignored (too frequent)' });
      }
    }
    
    // Ініціалізація кешу, якщо його немає
    if (!req.app.locals.progressCache) {
      req.app.locals.progressCache = {};
    }
    req.app.locals.progressCache[cacheKey] = Date.now();
    
    // Get manga details to ensure it exists and get title
    let manga;
    try {
      manga = await getMangaById(manhwaId);
    } catch (error) {
      console.error('Error fetching manga details:', error);
      return res.status(404).json({ message: 'Manga not found' });
    }
    
    // Find existing progress or create new
    let progress = await ManhwaProgress.findOne({
      user: req.user.id,
      manhwaId
    });
    
    let expGained = 0;
    let message = 'Reading progress updated';
    
    if (progress) {
      // Update existing progress
      const updateFields = {};
      let hasChanges = false;
      
      if (lastChapterRead !== undefined && lastChapterRead !== progress.lastChapterRead) {
        updateFields.lastChapterRead = lastChapterRead;
        hasChanges = true;
      }
      
      if (isCompleted !== undefined && isCompleted !== progress.isCompleted) {
        // Award exp for completing a manhwa if not previously completed
        if (isCompleted && !progress.isCompleted) {
          expGained += EXP_REWARDS.READ_MANHWA || 50;
          message = 'Manhwa completed! +50 EXP';
        }
        updateFields.isCompleted = isCompleted;
        hasChanges = true;
      }
      
      if (rating !== undefined && rating !== progress.rating) {
        // Award exp for rating if not rated before
        if (rating > 0 && progress.rating === 0) {
          expGained += EXP_REWARDS.RATE_MANHWA || 5;
          message = `${message} | Rated a manhwa! +5 EXP`;
        }
        updateFields.rating = rating;
        hasChanges = true;
      }
      
      if (review !== undefined && review !== progress.review) {
        // Award exp for review if not reviewed before
        if (review && !progress.review) {
          expGained += EXP_REWARDS.WRITE_REVIEW || 20;
          message = `${message} | Review added! +20 EXP`;
        }
        updateFields.review = review;
        hasChanges = true;
      }
      
      if (status !== undefined && status !== progress.status) {
        updateFields.status = status;
        hasChanges = true;
      }
      
      if (isLiked !== undefined && isLiked !== progress.isLiked) {
        updateFields.isLiked = isLiked;
        hasChanges = true;
      }
      
      // Якщо немає змін, не оновлюємо
      if (!hasChanges) {
        return res.json({
          progress,
          expGained: 0,
          message: 'No changes detected'
        });
      }
      
      // Update experience gained
      if (expGained > 0) {
        updateFields.experienceGained = progress.experienceGained + expGained;
      }
      
      progress = await ManhwaProgress.findOneAndUpdate(
        { user: req.user.id, manhwaId },
        { $set: updateFields },
        { new: true }
      );
    } else {
      // Create new progress
      progress = new ManhwaProgress({
        user: req.user.id,
        manhwaId,
        title: manga.title,
        coverImage: manga.coverImage,
        lastChapterRead: lastChapterRead || 0,
        isCompleted: isCompleted || false,
        rating: rating || 0,
        review: review || '',
        status: status || 'reading',
        isLiked: isLiked || false
      });
      
      // Award exp for starting a new manhwa
      expGained = 10; // Small bonus for starting
      progress.experienceGained = expGained;
      message = 'Manhwa added to your list! +10 EXP';
      
      await progress.save();
    }
    
    // Update user experience if exp was gained
    if (expGained > 0) {
      try {
        const user = await User.findById(req.user.id);
        if (user) {
          user.addExperience(expGained);
          await user.save();
        }
      } catch (error) {
        console.error('Error updating user experience:', error);
        // Не відправляємо помилку, бо основне оновлення пройшло успішно
      }
    }
    
    res.json({
      progress,
      expGained,
      message
    });
  } catch (error) {
    console.error('Error in updateReadingProgress:', error);
    next(error);
  }
};

module.exports = {
  searchManhwas,
  getManhwaDetails,
  getManhwaChapters,
  getChapterContent,
  updateReadingProgress
};